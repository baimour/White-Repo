var hideView = h5gg.loadPlugin("ayHide", "h5gg_hideview.dylib");

//关闭过直播
//hideView.changeHidden(0);
//开启过直播
hideView.changeHidden(1);

//HOOK源触摸函数，同步过直播view的触摸开关
var orig_setWindowTouch = setWindowTouch;
setWindowTouch = function(isTouch) {
    var boolNum = isTouch ? 1 : 0;
    hideView.changeTouch(boolNum);
    orig_setWindowTouch(isTouch);
}

//禁止触摸
//hideView.changeTouch(0);
//启用触摸
//hideView.changeTouch(1);
//alert("开启过直播以后请勿点击任何一个输入框");
